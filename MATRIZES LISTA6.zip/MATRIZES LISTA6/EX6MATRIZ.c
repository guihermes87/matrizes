#include <stdio.h>

int main() {
    int matriz[4][3], i, j, soma, maior, menor, linha_maior, linha_menor;

    printf("Digite os elementos da matriz [%d][%d] 4x3:\n",i,j);
    for (i = 0; i < 4; i++)
        for (j = 0; j < 3; j++)
            scanf("%d", &matriz[i][j]);

    maior = menor = 0;
    for (j = 0; j < 3; j++) {
        maior += matriz[0][j];
        menor += matriz[0][j];
    }
    linha_maior = linha_menor = 0;

    for (i = 1; i < 4; i++) {
        soma = 0;
        for (j = 0; j < 3; j++) {
            soma += matriz[i][j];
        }
        if (soma > maior) {
            maior = soma;
            linha_maior = i;
        }
        if (soma < menor) {
            menor = soma;
            linha_menor = i;
        }
    }

    printf("Linha com maior soma: %d\n", linha_maior);
    printf("Linha com menor soma: %d\n", linha_menor);

    return 0;
}
