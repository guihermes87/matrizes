#include <stdio.h>

int main() {
    int matriz[3][4], vetor[4], linha;

    printf("Digite os elementos da matriz 3x4:\n");
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 4; j++)
            scanf("%d", &matriz[i][j]);

    printf("Digite o número da linha que deseja copiar (0 a 2): ");
    scanf("%d", &linha);

    for (int j = 0; j < 4; j++) {
        vetor[j] = matriz[linha][j];
    }

    printf("Vetor copiado:\n");
    for (int j = 0; j < 4; j++) {
        printf("%d ", vetor[j]);
    }
    printf("\n");

    return 0;
}
