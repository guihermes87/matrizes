#include <stdio.h>

int main() {
    int A[3][3], B[3][3], somaA = 0, somaB = 0, i;

    printf("Digite a matriz A 3x3:\n");
    for (i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            scanf("%d", &A[i][j]);

    printf("Digite a matriz B 3x3:\n");
    for (i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            scanf("%d", &B[i][j]);

    for (i = 0; i < 3; i++) {
        somaA += A[i][i];
        somaB += B[i][i];
    }

    if (somaA == somaB)
        printf("As somas das diagonais principais são iguais.\n");
    else
        printf("As somas das diagonais principais são diferentes.\n");

    return 0;
}

