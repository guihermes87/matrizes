#include <stdio.h>

int main() {
    int A[5][5], i, j, valor, cont = 0, maior;
    printf("Digite os elementos da matriz 5x5:\n");
    for (i = 0; i < 5; i++)
        for (j = 0; j < 5; j++)
            scanf("%d", &A[i][j]);

    printf("Digite um valor para contar ocorrências: ");
    scanf("%d", &valor);
    for (i = 0; i < 5; i++)
        for (j = 0; j < 5; j++)
            if (A[i][j] == valor)
                cont++;
    printf("O valor %d aparece %d vezes\n", valor, cont);

    maior = A[0][0];
    for (i = 0; i < 5; i++)
        for (j = 0; j < 5; j++)
            if (A[i][j] > maior)
                maior = A[i][j];

    printf("Maior elemento: %d\n", maior);
    printf("Ocorrências do maior elemento:\n");
    for (i = 0; i < 5; i++)
        for (j = 0; j < 5; j++)
            if (A[i][j] == maior)
                printf("Linha %d, Coluna %d\n", i, j);

    return 0;
}

