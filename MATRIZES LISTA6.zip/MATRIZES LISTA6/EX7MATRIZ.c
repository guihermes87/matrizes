#include <stdio.h>

int main() {
    int matriz[4][4], i, j;
    int soma_coluna1 = 0, mult_linha1 = 1, soma_diag = 0, soma_total = 0;

    printf("Digite os elementos da matriz 4x4:\n");
    for (i = 0; i < 4; i++)
        for (j = 0; j < 4; j++) {
            scanf("%d", &matriz[i][j]);
            if (j == 0) soma_coluna1 += matriz[i][j];
            if (i == 0) mult_linha1 *= matriz[i][j];
            if (i == j) soma_diag += matriz[i][j];
            soma_total += matriz[i][j];
        }

    printf("Soma da primeira coluna: %d\n", soma_coluna1);
    printf("Multiplicação da primeira linha: %d\n", mult_linha1);
    printf("Soma da diagonal principal: %d\n", soma_diag);
    printf("Soma de todos os elementos: %d\n", soma_total);

    return 0;
}

